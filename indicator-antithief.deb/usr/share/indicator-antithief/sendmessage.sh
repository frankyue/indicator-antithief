#!/bin/sh
cliofetion  -f 1596718**** -p ********  -t ******* -d 'Your computer is in dangerous!'
